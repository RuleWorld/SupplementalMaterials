import numpy as np
import matplotlib.pyplot as plt
import matplotlib.lines as lin
import seaborn.apionly as sns
import scipy.stats.mstats as st
import matplotlib.colors as clr
from matplotlib.font_manager import FontProperties

def rxnplot(df,save=0):
	
	df1 = df[df['Specification'].isin(['RBM'])]
	x = np.array([X for (X,Y) in sorted(zip(df1['Entities'],df1['Processes']))])
	y = np.array([Y for (X,Y) in sorted(zip(df1['Entities'],df1['Processes']))])
	fit = np.polyfit(np.log10(x),np.log10(y),deg=1)
	yfit1 = np.power(10,fit[0]*np.log10(x) +fit[1])
	x1 = np.array(x,copy=True)
	y1 = np.array(y,copy=True)
	
	df2 = df[df['Specification'].isin(['RNM'])]
	x = np.array([X for (X,Y) in sorted(zip(df2['Entities'],df2['Processes']))])
	y = np.array([Y for (X,Y) in sorted(zip(df2['Entities'],df2['Processes']))])
	fit = np.polyfit(np.log10(x),np.log10(y),deg=1)
	yfit2 = np.power(10,fit[0]*np.log10(x) +fit[1])
	x2 = np.array(x,copy=True)
	y2 = np.array(y,copy=True)
	
	
	fig = plt.figure(figsize=(3.7,3.7))
	ax = plt.gca()
	fnt = {'fontname':'Arial'}
	fontP = FontProperties()
	fontP.set_name('Arial')

	ax.plot(x1, yfit1,color='blue')	
	ax.scatter(x1,y1,c='blue',alpha=0.5,label='RBM')
	#[ax.add_line(lin.Line2D(x0,y0)) for (x0,y0) in zip(x,y)]
	
	ax.plot(x2, yfit2,color='red')
	ax.scatter(x2,y2,c='red',alpha=0.5,label='RNM')
	
	models = df1['Model']
	for m in models:
		ind1 = df1['Model'].isin([m])
		[x1,y1] = list(df1[ind1].iloc[0][['Entities','Processes']])
		ind2 = df2['Model'].isin([m])
		[x2,y2] = list(df2[ind2].iloc[0][['Entities','Processes']])
		ax.add_line(lin.Line2D([x1,x2],[y1,y2],c='black',alpha=0.2))
		
	ax.set_xscale('log')
	ax.set_yscale('log')
	ax.set_xlim([5,2e3])
	ax.set_ylim([5,2e4])
	[x.label.set_fontname('Arial') for x in ax.xaxis.get_major_ticks()]
	[x.label.set_fontname('Arial') for x in ax.yaxis.get_major_ticks()]
	ax.legend(loc=2,scatterpoints=1,fancybox=1,handlelength=.5,handletextpad=.5,prop=fontP)
	#ax.set_xlabel('Entities',fontname='Arial')
	#ax.set_ylabel('Processes',fontname='Arial')
	
	plt.tight_layout()

	if(save==1):
		plt.savefig('rxnnet',dpi=600)
	else:
		plt.show()
	return ax
	
def modelscatter(df,save=0):
	ord = ['CMap',
	'ConvRule', 'CompactRule', 'SimmuneNet',
	'RInf','FullReg',
	'RegNoBkg', 'RegGrps','RegGrpsNoCtxt']
	with sns.axes_style("whitegrid"):
		g = sns.FacetGrid(df,col='Graph',
		col_order=ord,col_wrap=3,size=1.5,aspect=2)
	nmodels = len(df['Model'].unique())
	with sns.axes_style("whitegrid"):
		g.map(sns.regplot,'Nodes','EdgesPerNode',color="blue",fit_reg=False,scatter_kws={"alpha":'0.75'})
	
	titles = ['(A) Conventional\nRule Visualization', 
	'(B) Compact\nRule Visualization', 
	'(C) Simmune\nNetwork Viewer', 
	'(D) Contact\nMap', '(E) Rule\nInfluence Diagram', '(F) Model\nRegulatory Graph',
	'(G) Background\nRemoved', '(H) Groups Compressed with\n Strict Edge Signature','(I) Groups Compressed with\n Permissive Edge Signature' ]
	fntsz = 10
	titles = ['A','B','C','D','E','F','G','H','I']
	[ax.set_title(tt,fontsize=fntsz,fontname="Arial",fontweight='bold') for ax,tt in zip(g.axes,titles)]
	#[ax.set_title(" ",fontsize=fntsz,fontname="Arial",fontstyle="bold") for ax in g.axes]
	x0 = 1; x1 = 20000; y0 = 0.5; y1 = 120;
	g.set(xscale='log',yscale='log',xlim=[x0,x1],ylim=[y0,y1],xlabel='',ylabel='')
	
	medx_all = [ st.gmean(x[1]['Nodes']) for x in list(g.facet_data()) ]
	medy_all = [ st.gmean(x[1]['EdgesPerNode']) for x in list(g.facet_data()) ]
	for ax,medx,medy in zip(g.axes,medx_all,medy_all):
		ax.scatter(x=[medx],y=[medy],color="red",alpha=0.5,s=50)
		
	for ax in g.axes:	
		xticklabels = [tick.label for tick in ax.xaxis.get_major_ticks()]
		yticklabels = [tick.label for tick in ax.yaxis.get_major_ticks()]
		[x.set_fontname('Arial') for x in xticklabels]
		[x.set_fontsize('7') for x in xticklabels]
		[y.set_fontname('Arial') for y in yticklabels]
		[y.set_fontsize('7') for y in yticklabels]
		
	g.axes[3].set_ylabel('Edges per Node',fontsize=8,fontname="Arial")
	g.axes[7].set_xlabel('Nodes',fontsize=8,fontname="Arial")
	plt.tight_layout()
	
	if(save==1):
		plt.savefig('modelgraphs',dpi=600)
	else:
		plt.show()
	
	return g
	
def gmeansplot(df,save=0):
	structure = ['CMap']
	mechanism = ['ConvRule','CompactRule','SimmuneNet']
	regulation = ['RInf','FullReg']
	function = ['RegNoBkg','RegGrps','RegGrpsNoCtxt']
	
	maps = [structure,mechanism,regulation,function]
	
	color_structure  = ['#93a24e']
	color_mechanism = ['#823535','#ba4d4c','#ce8281']
	color_regulation = ['#1e5b82','#2b83ba']
	color_function = ['#713a6c','#a2539b','#bd86b9']
	colors = [color_structure,color_mechanism,color_regulation,color_function]
	
	maps2 = [j for i in maps for j in i]
	colors2 = [j for i in colors for j in i]
		
	f, ax = plt.subplots(figsize=(4,4))
	for (mp,co) in zip(maps2, colors2):
		x = df[df['Graph'].isin([mp])]['Nodes']
		y = df[df['Graph'].isin([mp])]['EdgesPerNode']
		ax.scatter(x,y,c=co,s=250,alpha=0.7,edgecolors=co)
	
	ax.set_xscale('log')
	ax.set_yscale('log')
	
	ax.set_xlim([10,1000])
	ax.set_ylim([0.5,20])
	
	plt.grid(True)
	plt.tight_layout()
	
	if(save==1):
		plt.savefig('gmeans',dpi=600)
	else:
		plt.show()
	return ax
	
def gmeansplot2(df,save=0):
	structure = ['CMap']
	mechanism = ['ConvRule','CompactRule','SimmuneNet']
	regulation = ['RInf','FullReg']
	function = ['RegNoBkg','RegGrps','RegGrpsNoCtxt']
	
	maps = [structure,mechanism,regulation,function]
	maps2 = [j for i in maps for j in i]
	
	marker_structure = [r'$S1$']
	marker_mechanism = [r'$M1$',r'$M2$',r'$M3$']
	marker_regulation = [r'$R1$',r'$R2$']
	marker_function = [r'$F1$',r'$F2$',r'$F3$']
	markers = [marker_structure, marker_mechanism, marker_regulation, marker_function]
	markers2 = [j for i in markers for j in i]
	
	#annot_structure = ['S1']
	#annot_mechanism = ['M1','M2','M3']
	#annot_regulation = ['R1','R2']
	#annot_function = ['F1','F2','F3']
	
	annot_structure = ['cmap']
	annot_mechanism = ['rv','crv','sim']
	annot_regulation = ['rinf','ar']
	annot_function = ['ar$_1$','ar$_2$','ar$_3$']
	
	annot = [annot_structure,annot_mechanism,annot_regulation,annot_function]
	annot2 = [j for i in annot for j in i]
	
	color_structure = ['#D55E00'] * 1
	color_mechanism = ['k'] * 3
	color_regulation = ['#0072B2'] * 2
	color_function = ['#009E73'] * 3
	colors = [color_structure,color_mechanism,color_regulation,color_function]
	colors2 = [j for i in colors for j in i]
	
	f, ax = plt.subplots(figsize=(4,4))
	for mp,tx,c in zip(maps2,annot2,colors2):
		
		x = df[df['Graph'].isin([mp])]['Nodes']
		y = df[df['Graph'].isin([mp])]['EdgesPerNode']
		ax.scatter(x,y,c='k',marker='o',s=5)
		
		offset_x = 0.1
		offset_y = -0.02 - 0.02*(tx=='ar$_3$')
		h='left	'
		v='center'
		x_txt = x*(1+offset_x)
		y_txt = y*(1+offset_y)
		ax.annotate(tx,(x_txt,y_txt),color='0.25',horizontalalignment=h,verticalalignment=v)
	
	ax.set_xscale('log')
	ax.set_yscale('log')
	
	ax.set_xlim([5,1200])
	ax.set_ylim([0.5,20])
	
	plt.grid(True)
	plt.tight_layout()
	
	if(save==1):
		plt.savefig('gmeans2',dpi=600)
	else:
		plt.show()
	return ax
	
#gmeansplot2(gmeans)
	
def ruledist(df,save=0):
	headers = df.columns[2:5]
	#titles = {0:'(A)\nRule Syntax Graph',1:'(B)\nRule Structure Graph',2:'(C)\nRule Regulatory Graph'}
	
	fig,axs = plt.subplots(1,3,figsize=(10,3))
	binsize = [4,2,1]
	nmodels = len(df['Model'].unique())
	nrules = len(df)
	majorticks= np.arange(0,401,100)
	for col in [0,1,2]:
		with sns.axes_style("whitegrid"):
			sns.distplot(df[headers[col]],ax=axs[col],kde=False,norm_hist=False,bins=range(0,df[headers[col]].max()+1,binsize[col]),color="red",hist_kws={'alpha':0.5})
		
		#axs[col].set_title(titles[col],fontname='Arial',size=12)
		axs[col].set_xlabel('')
		axs[col].set_ylabel('')
		axs[col].set_ylim([0,450])
		axs[col].set_yticks(majorticks)
		xticklabels = [tick.label for tick in axs[col].xaxis.get_major_ticks()]
		yticklabels = [tick.label for tick in axs[col].yaxis.get_major_ticks()]
		[x.set_fontname('Arial') for x in xticklabels]
		[x.set_fontsize('10') for x in xticklabels]
		[y.set_fontname('Arial') for y in yticklabels]
		[y.set_fontsize('10') for y in yticklabels]
		
	#axs[1].set_xlabel('Number of Nodes',fontname='Arial',size=10)
	#axs[0].set_ylabel('Number of Rules',fontname='Arial',size=10)
	plt.tight_layout()
	plt.show()
	if(save==1):
		plt.savefig('rulegraphs',dpi=600)
	
	return axs
	