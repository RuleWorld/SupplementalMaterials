import pandas as pd
import scipy.stats.mstats as st
def importdata():
	rules = pd.read_csv('data_rules.csv')
	nodes = pd.read_csv('data_models_nodes.csv')
	edges = pd.read_csv('data_models_edges.csv')
	
	edgespernode = pd.DataFrame()
	modelnames = nodes['Model']
	headers = list(nodes.columns[1:])
	frames = []
	for m in modelnames:
		loc = (nodes.Model == m)
		n =  nodes[loc][headers].values.tolist()[0]
		e =  edges[loc][headers].values.tolist()[0]
		epn = [ float(x)/float(y) for (x,y) in zip(e,n)] 
		df = pd.DataFrame({ 'Model':m,'Graph':headers,'Nodes':n,'Edges':e,'EdgesPerNode':epn })
		df = df[['Model','Graph','Nodes','Edges','EdgesPerNode']]
		frames.append(df)
	models = pd.concat(frames,ignore_index=True)
	order = ['ConvRule','CompactRule','SimmuneNet',
	'CMap','RInf','FullReg',
	'RegNoBkg','RegGrps','RegGrpsNoCtxt']
	models['Model'] = pd.Categorical(models['Model'])
	models['Graph'] = pd.Categorical(models['Graph'],order)
	models.sort_values(by=['Model','Graph'],inplace=True)
	models.reset_index(inplace=True)
	models.drop(['index'],inplace=True,axis=1) 
	
	rxns_in = pd.read_csv('data_models_rxns.csv')
	modelnames = rxns_in['Model']
	frames = []
	for m in modelnames:
		loc = (rxns_in.Model == m)
		pa = rxns_in[loc]['Patterns'].values.tolist()[0]
		ru = rxns_in[loc]['Rules'].values.tolist()[0]
		sp = rxns_in[loc]['Species'].values.tolist()[0]
		rn = rxns_in[loc]['Reactions'].values.tolist()[0]
		#df1 = pd.DataFrame({ 'Model':m, 'Specification':['Rule-based Model (RBM)'], 'Entities':pa, 'Processes':ru })
		#df2 = pd.DataFrame({ 'Model':m, 'Specification':['Reaction Network Model (RNM)'], 'Entities':sp, 'Processes':rn })
		df1 = pd.DataFrame({ 'Model':m, 'Specification':['RBM'], 'Entities':pa, 'Processes':ru })
		df2 = pd.DataFrame({ 'Model':m, 'Specification':['RNM'], 'Entities':sp, 'Processes':rn })
		frames.append(df1)
		frames.append(df2)
	rxns = pd.concat(frames,ignore_index=True)
	rxns = rxns[['Model','Specification','Entities','Processes']]
	
	
	df2 = models.drop(['Edges'],axis=1)
	gmeans = df2.groupby(['Graph']).agg(lambda x: st.gmean(tuple(x)))
	gmeans['Graph'] = gmeans.index
	
	return rules,models,rxns,gmeans
	
(rules,models,rxns,gmeans) = importdata()
