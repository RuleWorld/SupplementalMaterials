
Requirements: numpy, scipy, matplotlib,seaborn, pandas

To initialize:
$ ipython
> run data.py
> run plotter.py

To get the chart in Fig 10 (main text), run
> ax = gmeansplot2(gmeans)
To get the charts in Fig S3, run
> ax = modelscatter(models)

