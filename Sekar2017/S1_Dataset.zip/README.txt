For Chylek and Creamer libraries, execute the respective BNGL files from commandline, i.e., 

BNGPATH\BNG2.pl modelname.bngl

This will generate modelname_regulatory.gml. Open this file in yEd and perform Organic Layout to get a graph identical to the attached modelname_regulatory_backup.gml

----------------

For Suderman & Deeds model, follow tutorial in S7 Appendix

----------------